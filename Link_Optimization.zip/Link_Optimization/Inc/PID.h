/*
 * PID.h
 *
 *  Created on: Feb 18, 2024
 *      Author: A
 */

#ifndef PID_H_
#define PID_H_
#include "tim.h"
#include "algorithm.h"
#include "Servo_Move.h"
#include "algorithm.h"



void Motor_Position(void);
void PID_function(void);


#endif /* PID_H_ */
