/*
 * Servo_Move.c
 *
 *  Created on: Feb 12, 2024
 *      Author: A
 */
#include "Servo_Move.h"
#include "algorithm.h"
#include "systick.h"




void Motor_Position(void)
{

    if (RSSI_OLD > RSSI_NEW)	//Algorithm guess based on comparison of RSSI_OLD and RSSI_NEW
    {
    	xPos = xPos - 5;	//Subtracts from variable representative for the x axis
    	yPos = yPos - 5;	//Subtracts from variable representative for the y axis
    	TIM2->CCR1 = xPos;	//Moves in negative X axis
    	TIM2->CCR2 = yPos;	//Moves in negative Y axis
        rssi = RSSI_OLD;	//Stores OLD RSSI
        delay(20);			//Hardware delay
    }
    if (RSSI_OLD < RSSI_NEW)	//Algorithm guess based on comparison of RSSI_OLD and RSSI_NEW
    {
    	xPos = xPos + 5;	//Adds to variable representative for the x axis
    	yPos = yPos + 5;	//Adds to variable representative for the y axis
    	TIM2->CCR1 = xPos;	//Moves in negative X axis
    	TIM2->CCR2 = yPos;	//Moves in negative Y axis
        rssi = RSSI_NEW;	//Stores OLD RSSI
        delay(20);			//Hardware delay
    }

/**********************Testing Purposes********************************/

	if(xPos < 91 || xPos > 400)		//Checks if X axis is out of range
	{
		xPos = 80;					//Sets X axis in range
	}
	if(yPos < 190 || yPos > 230)	//Checks if Y axis is out of range
	{
		yPos = 190;					//Sets Y axis in range
	}

}

void control_X(void)
{
	/**********************************************/
	//scanf for input x and y position
	//subtract x_abs from xPos
	//store in delta
	//delta/2 or a fractional portion
	//set delta/2 as variable positioning
	//TIM2->CCR1 = xPos + positioning
    int xPos_abs = 400;				//Greatest range in X axis
    int deltaX = xPos - xPos_abs;	//Subtracts current x position from theoretical greatest range
    int xVar = 2;					//Division variable for control of movement
    int x_Positioning;

//	xPos_abs = 230.;
	deltaX = xPos_abs - xPos;
    x_Positioning = deltaX / 2;
    xPos = xPos + x_Positioning;
    TIM2->CCR1 = xPos;
    delay(20);

    xPos++;

    if (xPos == 400) {
        xPos = 93;
    }
	return;
}


void control_Y(void)
{
    int yPos_abs = 230;
    int deltaY = yPos - yPos_abs;
    int yVar = 2.;
    int y_Positioning;

//	yPos_abs = 230.;
	deltaY = yPos_abs - yPos;
    y_Positioning = deltaY / yVar;
    xPos = yPos + y_Positioning;
    TIM2->CCR2 = yPos;
    delay(20);

    yPos++;

    if (yPos == 230) {
        yPos = 190;
    }
  }

