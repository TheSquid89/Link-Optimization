/*
 * process_console.c
 *
 *  Created on: Feb 8, 2024
 *      Author: A
 */
#include "process_console.h"
#include "algorithm.h"

uint8_t manual_mode = 0;

void process_console(void)
{
	char cmd;
	char ch;
	uint16_t value;

	if(kbhit())
		{
			cmd = uart2_read();
			ch = uart2_read();	// dummy read of '='
			value = 0;
			ch = uart2_read();
			while (ch != 13) {
				value = 10 * value + ch - '0';
				ch = uart2_read();
			}

		    switch(cmd) {
				case 'm':
					manual_mode = value;
					break;

		        case 'x':	// command x=123<cr>
//#if 0
		        	xPos = 150;
//#else
		        	xPos = value;
//#endif
		        	TIM2->CCR1 = xPos;
		            break;
		        case 'X':

		        	xPos = 300;
		        	yPos = 250;
		        	TIM2->CCR1 = xPos;
		        	TIM2->CCR2 = yPos;
		            break;
		        case 'y':
		        	yPos = 190;
		        	TIM2->CCR1 = xPos;
		            break;
		        case 'Y':
		        	xPos = 300;
		        	yPos = 250;
		        	TIM2->CCR1 = xPos;
		        	TIM2->CCR2 = yPos;
		            break;
		        case 'R':
		        	xPos = 91;
		        	yPos = 190;
		        	TIM2->CCR1 = xPos;
		        	TIM2->CCR2 = yPos;
		        	break;
		        case 's':
		        	scanning_function();
		        	break;

		        default:
		        	printf("Input invalid\n\r");
		        	break;

		    }

	}

}
