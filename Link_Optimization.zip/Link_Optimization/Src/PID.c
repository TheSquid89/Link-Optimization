/*
 * PID.c
 *
 *  Created on: Feb 18, 2024
 *      Author: A
 */
#include "PID.h"
#include "stm32f4xx.h"

// PID Controller Parameters
#define KP 1.0f   // Proportional gain
#define KI 0.1f   // Integral gain
#define KD 0.01f  // Derivative gain
#define DT 0.01f  // Time step (sampling time)

// PID Controller Variables
float error = 0.0f;
float prev_error = 0.0f;
float integral = 0.0f;
float derivative = 0.0f;
float output = 0.0f;

// Target Position (desired setpoint)
float setpoint = 0.0f;

// Current Position (measured process variable)
float position = 0.0f;

// PID Controller Function
float PID_Controller(float setpoint, float position) {
    // Calculate error
    error = setpoint - position;

    // Calculate integral
    integral += error * DT;

    // Calculate derivative
    derivative = (error - prev_error) / DT;

    // Calculate PID output
    output = KP * error + KI * integral + KD * derivative;

    // Update previous error
    prev_error = error;

    return output;
}
